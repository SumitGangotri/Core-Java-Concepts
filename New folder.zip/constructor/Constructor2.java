package constructor;

public class Constructor2 {
	
	int a; String b; boolean c;
	
	Constructor2(){                //Default Constructor
		a=1000; b="Sumit"; c=true;
	}
	
	void show() {
		System.out.println(a+" "+b+" "+c);
	}
}

	class Cons{
		public static void main(String[] args) {
		Constructor2 c2=new Constructor2();
		
		c2.show();
		}
		
	}
	

