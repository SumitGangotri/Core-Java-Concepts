package constructor;

public class Private_constructor {

	int a; double b; String c;
	
	private Private_constructor(){
		a=10; b=23.23; c="Sumit";
		System.out.println(a+" "+b+" "+c);
	}
	
	static void show() {
		
	}
	
	public static void main(String[] args) {
		
		Private_constructor pc=new Private_constructor();
		

	}

}
