package encapsulation;

import java.util.Scanner;

public class Cricket {
	
	private String name="Sachin";
	private int age=40;
	private int runs=18000;
	private int wickets=200;
	private int pwd;
	
	public void total_runs(int total) {
		System.out.println("Enter your password:");
		Scanner sc=new Scanner(System.in);
		pwd=sc.nextInt();
		if(pwd==345) {
//			runs=runs+total;
			System.out.println("Score Runs:"+ total);
			System.out.println("Total runs:"+ runs);
		}
		else {
			System.out.println("Wrong Password");
		}
		
	}
	
	public void total_wicket(int total) {
		System.out.println("Enter your password:");
		Scanner sc=new Scanner(System.in);
		pwd=sc.nextInt();
		if(pwd==345) {
//			wickets=wickets+total;
			System.out.println("Wickets Claim:"+ total);
			System.out.println("Total wickets:"+ wickets);
		}
		else {
			System.out.println("Wrong Password");
		}
	}
	
	public void checktotal() {
		System.out.println("Enter your Password");
		
		Scanner sc=new Scanner(System.in);
		pwd=sc.nextInt();
		if(pwd==345) {
			System.out.println("Player Name: "+name+" "+"Player Age: "+age+" "+ "Total runs: "+runs+" "+"Total Wickets: "+wickets);
		}
		else {
			System.out.println("Incorrect Password:");
		}
	}
}

	class Player{
			
			public static void main(String[] args) {
				Cricket b=new Cricket();
				
				int ch;
				System.out.println("1. Total Runs:");
				System.out.println("2. Total Wickets:");
				System.out.println("3. Total:");
				
				System.out.println("\nEnter Your Choice:");
				Scanner s2=new Scanner(System.in);
				ch=s2.nextInt();
				
				
				switch(ch) {
				case 1: b.total_runs(18000);
				break;
				case 2: b.total_wicket(200);
				break;
				case 3: b.checktotal();
				break;
				default: System.out.println("Invalid Choice:");
				}
			}
		}


