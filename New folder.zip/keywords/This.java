package keywords;

//public class This {
//	
//	void show() {
//		System.out.println(this);
//	}
//
//	public static void main(String[] args) {
//		
//		This t=new This();
//		System.out.println(t);
//		
//		t.show();
//	}
//
//}

//This (For calling Parameterized Constructor)

//public class This {
//	
//	int a;
//	This(int a){
//		this.a=a;
//	}
//	void show() {
//		System.out.println(a);
//	}
//
//	public static void main(String[] args) {
//		
//		This t=new This(100);		
//		t.show();
//	}
//
//}

//This (For calling Default Constructor)

//public class This {
//	
//	This(){          
//		System.out.println("LearnCoding");
//	}
//	This(int a){
//		this();
//		System.out.println(a);
//	}
//
//	public static void main(String[] args) {
//		
//		This t=new This(100);		
//	}
//
//}


/* Instance Vs Static Blocks */

public class This {
	
	//Instance
//	This(){          
//		System.out.println("Default Constructor");
//	}
//	{
//		System.out.println("LearnCoding");
//	}
//
//	public static void main(String[] args) {
//		
//		This t=new This();		
//	}
	
	//Static
	static {
		System.out.println("LearnCoding");
	}
	public static void main(String[] args) {
		
	}

}


