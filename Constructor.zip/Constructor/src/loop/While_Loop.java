package loop;

import java.util.Scanner;

//Table using While Loop

public class While_Loop {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number: ");
		
		int num=sc.nextInt();
//		System.out.println("Enter Range: ");
//		
//		int range=sc.nextInt();
//		int i=1;
//		
//		while(i<=range) {
//			System.out.println(num+"*"+i+"="+num*i);
//			i++;
//		}
		
		//Even Number & Odd Number
		while(num>=0) {
			if(num%2==0) {
				System.out.println("Even Number");
				break;
			}
			else {
				System.out.println("Odd Number");
				break;
			}
			
		}

	}

}
