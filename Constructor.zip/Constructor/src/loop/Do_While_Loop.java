package loop;

import java.util.Scanner;

//Natural Number

public class Do_While_Loop {

	public static void main(String[] args) {
		int num;
		System.out.println("Enter Any Number:");
		Scanner sc=new Scanner(System.in);
		
		num=sc.nextInt();
		
		do {
			System.out.println(num);
			++num;
		}
		while(num<=10);
		
	}

}
