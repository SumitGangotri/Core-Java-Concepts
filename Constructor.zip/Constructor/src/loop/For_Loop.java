package loop;

import java.util.Scanner;

//Table using For Loop

public class For_Loop {

	public static void main(String[] args) {
		
		int num=2;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number: ");
		num=sc.nextInt();
		
		for(int i =1; i<=10; i++) {
			System.out.println(num+"*"+i+"="+num*i);
		}

	}

}
