package loop;

public class For_Each {

	public static void main(String[] args) {
		

	}

}
