package polymorphism;

//Method Overloading
//Compile Time Polymorphism

public class A {
	
	void add() {
		int a=10, b=20, c;
		c=a+b;
		System.out.println("Sum of Two Numbers: "+c);
	}
	
	void add(int x, int y) {
		
		int c;
		c=x+y;
		System.out.println("Sum of Two Numbers: "+c);
	}
	
	void add(int x, double y) {
		double c;
		c=x+y;
		System.out.println("Sum of Two Numbers: "+c);
	}

	public static void main(String[] args) {
		
		A a=new A();
		a.add();
		a.add(45, 5);
		a.add(50, 35.12);
	}

}
