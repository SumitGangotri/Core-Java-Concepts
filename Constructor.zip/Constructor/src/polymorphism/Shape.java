package polymorphism;

//Method Overriding
//Runtime Polymorphism

public class Shape {
	
	void draw() {
		System.out.println("Can't Say Shape Type");
	}
}
class Square extends Shape{
	
	@Override
	void draw() {
		
		super.draw();
		System.out.println("Square Shape");
	}
}

class Demo{
	
	public static void main(String[] args) {
		
		Shape r=new Square();
		r.draw();
		
	}
		

}
