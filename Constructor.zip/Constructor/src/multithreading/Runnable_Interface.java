package multithreading;

public class Runnable_Interface implements Runnable {


		public void run() {
			
			for(int i=1; i<=5;i++)
			{
				System.out.println("My Child Thread");
			}

	}

}
	
class C{
	public static void main(String[] args) {
		
		Runnable_Interface r=new Runnable_Interface();
		
		Thread t=new Thread(r);
		t.start();
		
		for(int i=0; i<=5; i++) {
			System.out.println("Main Thread");
		}
	}
}
