package package2;
import package1.*;

public class C extends Protected{

	public static void main(String[] args) {
		C r=new C();
		r.disp();

	}

}
