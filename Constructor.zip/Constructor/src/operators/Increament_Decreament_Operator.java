package operators;

public class Increament_Decreament_Operator {

	public static void main(String[] args) {
		
		int a=10;
		
		System.out.println(a--);     //10--->9
		System.out.println(--a);	 //8
		System.out.println(a++);     //8---->9
		System.out.println(++a);     //10

	}

}
