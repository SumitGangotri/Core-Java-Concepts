package interfacee;

public interface Vehical2 {
	
	String name="BMW";
	double price=5500000;
	String color="White";
	int model=2021;
	
	void model();
	void start();
	void stop();
	
	static void speed() {
		System.out.println("Car Speed is 250 Km/h");
	}

}

class Customer2 implements Vehical2{
	
	@Override
	public void model() {
		// TODO Auto-generated method stub
		System.out.println("Car Name: "+ name);
//		System.out.println("Car Speed: "+ speed);
		System.out.println("Car Color: "+ color);
		System.out.println("Car Price: "+ price);
		System.out.println("Car Model: "+ model);
	}

	@Override
	public void start() {
		
		System.out.println("Start(): Insert Key & Press Start Button");
		
	}

	@Override
	public void stop() {
		
		System.out.println("Stop(): Exit Key");	
		
	}

	public static void main(String[] args) {
		Customer2 c=new Customer2();
		c.model();
		Vehical2.speed();
		c.start();
		c.stop();
		
	}
	
	
}