package interfacee;

public interface Vehical {
	
	String name="TVS";   //public + static + final
	int speed=100;       //public + static + final
	
	void start();		//public + abstract
	void stop();        //public + abstract
}

class Customer implements Vehical{
	@Override          //When we override any method then we need to add @override annotation.
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("Vehical Name: "+ name);
		System.out.println("Vehical Speed: "+ speed);
		System.out.println("Start(): Insert Key & Press Start Button");
	
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		System.out.println("Stop(): Exit Key");
	}


	public static void main(String[] args) {
		Customer c=new Customer();
		c.start();
		c.stop();
	}
}

	