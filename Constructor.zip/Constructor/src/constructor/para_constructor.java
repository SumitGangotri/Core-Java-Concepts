package constructor;

public class para_constructor {

	int x,y;
	String name;
	para_constructor(int a,int b){
		x=a; y=b;
	}
	
	para_constructor(int a,String b){
		System.out.println(a+" "+b);
	}
	
	void display() {
		System.out.println(x+" "+y);
	}
	
}
	class para_const{
		
		public static void main(String[] args) {
			para_constructor p=new para_constructor(12,12);

			p.display();
			para_constructor v=new para_constructor(11,"Sumit");
			
			
			
			

		}
	}

