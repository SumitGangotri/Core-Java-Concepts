package constructor;

public class Copy_constructor {

	int a; String b;
	
	Copy_constructor(){
		a=10; b="LearnCoding";
		System.out.println(a+" "+b);
	}
	
	Copy_constructor(Copy_constructor ref){
		a=ref.a;
		b=ref.b;
		System.out.println(a+" "+b);
	}
}

class Copy{
	public static void main(String[] args) {
		Copy_constructor cc=new Copy_constructor();
		Copy_constructor cp=new Copy_constructor(cc);
		
		
		

	}

}
