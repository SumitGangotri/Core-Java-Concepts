package keywords;

//public class Super {
//	
//	int a=10;
//}
//
//class B extends Super{
//	
//	int a=20;
//	void show() {
//		System.out.println(a);
//		System.out.println(super.a);
//	}
//}
//
//class Test{
//
//	public static void main(String[] args) {
//		
//		B b=new B();
//		b.show();
//
//	}
//
//}

public class Super {
	
	void show() {
		System.out.println("Hello Viewer");
	}
	
}

class B extends Super{
	
	
	void show() {
		
		super.show();
		System.out.println("Hello Learner");
	
	}
}

class Test{

	public static void main(String[] args) {
		
		B b=new B();
		b.show();

	}

}
