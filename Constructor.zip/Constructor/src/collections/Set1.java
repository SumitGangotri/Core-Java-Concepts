package collections;

import java.util.HashSet;
import java.util.Set;

public class Set1 {

	public static void main(String[] args) {
		
		Set<Integer> set= new HashSet<>();
		
		set.add(44);
		set.add(66);
		set.add(12);
		set.add(86);
		
		System.out.println(set);
		
//		set.remove(66);
//		System.out.println(set);
		
		
		System.out.println(set.contains(44));
		
		System.out.println(set.isEmpty());
		
		set.clear();
		System.out.println(set);

	}

}
