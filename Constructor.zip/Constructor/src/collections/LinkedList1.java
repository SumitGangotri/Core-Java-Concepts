package collections;

import java.util.LinkedList;

public class LinkedList1 {

	public static void main(String[] args) {
		
		LinkedList<String> name=new LinkedList<String>();
		
		name.add("Sumit");
		name.add("Ankush");
		name.add("Ayush");
//		System.out.println(name);
//		
//		name.add(1,"Shruti");
//		System.out.println(name);
//		
//		name.addFirst("Pooja");
//		name.addLast("Nainu");
//		System.out.println(name);
//		
//		name.removeFirst();
//		System.out.println(name);
		
		for(String str:name) {
			System.out.println(str);
		}

	}

}
