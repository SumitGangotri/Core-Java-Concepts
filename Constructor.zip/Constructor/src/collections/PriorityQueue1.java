package collections;

import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueue1 {

	public static void main(String[] args) {
		
		Queue<Integer> pq=new PriorityQueue<>();
		
		pq.offer(33);
		pq.offer(22);
		pq.offer(88);
		pq.offer(55);
		
		System.out.println(pq);
		
		pq.poll();
		System.out.println(pq);
	}

}
