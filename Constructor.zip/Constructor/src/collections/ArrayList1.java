package collections;

import java.util.ArrayList;

public class ArrayList1 {

	public static void main(String[] args) {
		
		ArrayList<String> name=new ArrayList<String>();
		name.add("Sumit");
		name.add("Ankush");
		name.add("Ayush");
		
		System.out.println(name);
		
		name.add("Nainu");
		System.out.println(name);
		name.add(1,"Shruti");
		System.out.println(name);
		
		name.remove(3);
		System.out.println(name);
		
		name.remove(String.valueOf("Ankush"));
		System.out.println(name);
		
		name.set(1, "Pooja");
		System.out.println(name);
		
		System.out.println(name.get(0));
		
		System.out.println(name.contains("Sumit"));
		
		
//		name.removeAll(name);
//		System.out.println(name);

	}

}
