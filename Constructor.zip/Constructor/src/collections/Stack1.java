package collections;

import java.util.Stack;

public class Stack1 {

	public static void main(String[] args) {
		
		Stack<String> name=new Stack<String>();    //LIFO
		
		name.push("Sumit");
		name.push("Ankush");
		name.push("Nainu");
		
		System.out.println(name);
		
		System.out.println(name.peek());
		
		name.pop();
		System.out.println(name);
		
		

	}

}
