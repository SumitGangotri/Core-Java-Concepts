package collections;

import java.util.ArrayDeque;

public class ArrayDeque1 {

	public static void main(String[] args) {
		
		ArrayDeque<String> name=new ArrayDeque<String>();        //FIFO
		
		name.offer("Sumit");
		name.offer("Ankush");
		name.offer("Nainu");
		
		System.out.println(name);
		
		name.poll();
		System.out.println(name);
		
//		name.clear();
//		System.out.println(name);

	}

}
