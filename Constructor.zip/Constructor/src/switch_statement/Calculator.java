package switch_statement;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		int a,b,c,ch;
		
		System.out.println("Enter any Two Numbers: ");
		
		Scanner sc=new Scanner(System.in);
		
		a=sc.nextInt();
		b=sc.nextInt();
		
		System.out.println("Enter Your Choice: ");
		
		ch=sc.nextInt();
		
		switch(ch) {
		
		case 1: c=a+b;
				System.out.println("Addition of Two Numbers: "+c);
				break;
				
		case 2: c=a-b;
				System.out.println("Subtraction of Two Numbers: "+c);
				break;
				
		case 3: c=a*b;
				System.out.println("Multiplication of Two Numbers: "+c);
				break;
				
		case 4: c=a/b;
				System.out.println("Division of Two Numbers: "+c);
				break;
				
		case 5: c=a%b;
				System.out.println("Remainder of Two Numbers: "+c);
				break;
				
		default: System.out.println("Invalid Choice...!");
		}

	}

}
