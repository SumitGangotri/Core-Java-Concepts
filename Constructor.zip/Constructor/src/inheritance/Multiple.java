package inheritance;

//Multiple Inheritance

public interface Multiple {
	
	void show();
}

interface Multiple2{
	void show();
}

class Multiple3 implements Multiple,Multiple2{

	@Override
	public void show() {
		System.out.println("Interface A & B");
		
	}
	
	public static void main(String[] args) {
		Multiple3 m=new Multiple3();
		m.show();
	}

}
