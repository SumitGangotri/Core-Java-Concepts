package inheritance;

//Hierarchical Inheritance

public class Hierarchical {                            //Super Class

	void input() {
		System.out.println("Enter Your Name: ");
	}
}
	
class Hierar extends Hierarchical{                    //Sub Class
	
	void show() {
		System.out.println("My Name is Sumit");
	}
}

class Hi extends Hierarchical{                       //Sub Class
	
	void display() {
		System.out.println("My Name is Ankush");
	}
}

class Demo{

	public static void main(String[] args) {
		
		Hierar h=new Hierar();
		Hi h2=new Hi();
		
		h.input(); h.show();
		h2.input(); h2.display();

	}

}

