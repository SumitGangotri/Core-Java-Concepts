package inheritance;


//Single Level Inheritance

public class Student {
	
	int rollNo,marks;
	String name;
	
	void input() {
		System.out.println("Enter: RollNo   Name    Marks: ");
	}
}

class Sumit extends Student{
	void display() {
		rollNo=11; name="Sumit"; marks=74;
		System.out.println("         "+rollNo+"     "+name+"    "+marks);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Sumit s=new Sumit();
		s.input();
		s.display();

	}

}
