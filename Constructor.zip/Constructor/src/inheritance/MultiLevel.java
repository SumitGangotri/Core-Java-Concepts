package inheritance;


//Multilevel Inheritance

public class MultiLevel {                 //Super Class

	int a,b,c;
	void add() {
		a=12; b=48;
		c=a+b;
		System.out.println("Sum of Two Numbers: "+c);
	}
	
	void sub() {
		a=200; b=100;
		c=a-b;
		System.out.println("Subtraction of Two Numbers: "+c);
	}
}

class Level2 extends MultiLevel{         //Sub Class
	
	void mul() {
		a=20; b=5;
		c=a*b;
		System.out.println("Multiplication of Two Numbers: "+c);
	}
	
	void div() {
		a=25; b=5;
		c=a/b;
		System.out.println("Division of Two Numbers: "+c);
	}
}

class Level3 extends Level2{            //Sub Class
	
	void rem() {
		a=25; b=4;
		c=a%b;
		System.out.println("Reminder of Two Numbers: "+c);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Level3 l=new Level3();
		
		l.add();
		l.sub();
		l.mul();
		l.div();
		l.rem();

	}

}
