package file_handling;

import java.io.FileReader;
import java.io.IOException;

public class fileReader {

	public static void main(String[] args) {
		try {
			FileReader f=new FileReader("C:\\Users\\SRAJESHG\\LC.txt");
			try {
				int i;
				while((i=f.read())!=-1) {
				System.out.print((char)i);
			} 
			}
			finally {
				f.close();
				System.out.println("\nFile Closed...!");
			}
			System.out.println("Successfully File Read...!");
		} catch (IOException e) {
			// TODO: handle exception
			System.out.println(e);
		}

	}

}
