package file_handling;

import java.io.File;
import java.io.IOException;

public class CreateFile {

	public static void main(String[] args) {
		
		File f=new File("C:\\Users\\SRAJESHG\\LC.txt");
		try {
			if(f.createNewFile()) {
				System.out.println("File Successfully Created...!");
			}
			else {
				System.out.println("File Already Present");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception Handled...");
		}

}
}

