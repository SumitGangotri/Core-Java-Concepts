package file_handling;

import java.io.*;

public class fileWriter {

	public static void main(String[] args) {
		
		try {
			FileWriter f=new FileWriter("C:\\Users\\SRAJESHG\\LC.txt");
			try {
				f.write("Java is best Language...!");
			} 
			finally {
				f.close();
			}
			System.out.println("Successfully Data Wrote...!");
		} catch (IOException e) {
			// TODO: handle exception
			System.out.println(e);
		}

	}

}
