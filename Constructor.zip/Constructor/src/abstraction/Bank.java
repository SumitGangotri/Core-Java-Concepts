package abstraction;

import java.util.Scanner;

abstract class Bank {
	
	public String name="MyBank";
	public String axis="MyBank123";
	
	public void bankDetails() {
		System.out.println("Bank_Name: "+ name+" "+"Bank_Axis Code: "+axis);
	}
	
	abstract void deposit();
	abstract void withdraw();
	abstract void checkBal();
}

class BankService extends Bank{
	private double bal=5000;
	private int pwd;
	private double money;
	
	public void deposit() {
		System.out.println("Enter your Password");
		
		Scanner sc=new Scanner(System.in);
		pwd=sc.nextInt();
		if(pwd==234) {
			System.out.println("Enter Deposit Amount: ");
			money=sc.nextDouble();
			bal=bal+money;
			System.out.println("Deposited Money:" +money);
			System.out.println("Total Balance:" +bal);
		}
		else {
			System.out.println("Incorrect Password:");
		}
	}
	
	public void withdraw() {
		System.out.println("Enter your Password");
		
		Scanner sc=new Scanner(System.in);
		pwd=sc.nextInt();
		if(pwd==234) {
			System.out.println("Enter Withdraw Amount: ");
			money=sc.nextDouble();
			bal=bal-money;
			System.out.println("Withdrawn Money: "+money);
			System.out.println("Total Balance: "+bal);
		}
		else {
			System.out.println("Incorrect Password:");
		}
		
	}
	
		

	@Override
	void checkBal() {
System.out.println("Enter your Password");
		
		Scanner sc=new Scanner(System.in);
		pwd=sc.nextInt();
		if(pwd==234) {
			System.out.println("Total Balance: "+bal);
		}
		else {
			System.out.println("Incorrect Password:");
		}
}
		
	}

	
	class Customer{
		
		public static void main(String[] args) {
			BankService b=new BankService();
			b.bankDetails();
			
			int ch;
			System.out.println("1. Deposit:");
			System.out.println("2. Withdraw:");
			System.out.println("3. Check Balance:");
			
			System.out.println("\nEnter Your Choice:");
			Scanner s2=new Scanner(System.in);
			ch=s2.nextInt();
			
			
			switch(ch) {
			case 1: b.deposit();
			break;
			case 2: b.withdraw();
			break;
			case 3: b.checkBal();
			break;
			default: System.out.println("Invalid Choice:");
			}
		}
	}
