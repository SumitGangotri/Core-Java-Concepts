package abstraction;


abstract class Animal{
	void legs() {
		System.out.println("All Animals have 4 legs");
	}
	abstract void sound();
	abstract void eat();
}

class Dog extends Animal{
	@Override
	void sound() {
		System.out.println("Bow Bow...");
	}
	void eat() {
		System.out.println("Meat Eating");
	}
}

class Cow extends Animal{
	@Override
	void sound() {
		System.out.println("Oooooo...");
	}
	void eat() {
		System.out.println("Grass Eating");
	}
}

public class AbsClass {

	public static void main(String[] args) {
		
		Dog d=new Dog();
		Cow c=new Cow();
		
		d.sound();
		d.eat();
		d.legs();
		c.sound();
		c.eat();
		
		c.legs();
		
	}

}
