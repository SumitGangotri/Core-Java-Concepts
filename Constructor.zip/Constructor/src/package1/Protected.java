package package1;

public class Protected {

	protected void disp() {
		System.out.println("Sumit Here...!");
	}
}
class Pro extends Protected{
	public static void main(String[] args) {
		Pro a=new Pro();
		a.disp();
		
	}
}
