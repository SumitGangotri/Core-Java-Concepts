package package1;

public class Default {

	 void disp() {
		System.out.println("Sumit Here...!");
	}
}
class B{
	public static void main(String[] args) {
		Default a=new Default();
		a.disp();
		
	}

}
