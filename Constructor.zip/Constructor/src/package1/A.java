package package1;

public class A {
	
	void show() {
		System.out.println("Sumit Here...!");
	}
	public static void main(String[] args) {
		A a=new A();
		a.show();
	}
}
//class B{
//	public static void main(String[] args) {
//		A a=new A();
//		a.show();
//	}
//
//}
