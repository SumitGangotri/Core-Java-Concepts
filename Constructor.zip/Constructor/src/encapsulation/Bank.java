package encapsulation;

import java.util.Scanner;

public class Bank {

	private double bal=5000;
	private int pwd;
	
	public void Deposit(double money) {
		System.out.println("Enter your Password");
		
		Scanner sc=new Scanner(System.in);
		pwd=sc.nextInt();
		if(pwd==234) {
			bal=bal+money;
			System.out.println("Deposited Money:" +money);
			System.out.println("Total Balance:" +bal);
		}
		else {
			System.out.println("Incorrect Password:");
		}
	}

	public void Withdraw(double money) {
		System.out.println("Enter your Password");
		
		Scanner sc=new Scanner(System.in);
		pwd=sc.nextInt();
		if(pwd==234) {
			bal=bal-money;
			System.out.println("Withdrawn Money: "+money);
			System.out.println("Total Balance: "+bal);
		}
		else {
			System.out.println("Incorrect Password:");
		}
	}
		
	public void Checkbal() {
			System.out.println("Enter your Password");
			
			Scanner sc=new Scanner(System.in);
			pwd=sc.nextInt();
			if(pwd==234) {
				System.out.println("Total Balance: "+bal);
			}
			else {
				System.out.println("Incorrect Password:");
			}
	}
}

class Customer{
	
	public static void main(String[] args) {
		Bank b=new Bank();
		
		int ch;
		System.out.println("1. Deposit:");
		System.out.println("2. Withdraw:");
		System.out.println("3. Check Balance:");
		
		System.out.println("\nEnter Your Choice:");
		Scanner s2=new Scanner(System.in);
		ch=s2.nextInt();
		
		
		switch(ch) {
		case 1: b.Deposit(1000);
		break;
		case 2: b.Withdraw(2000);
		break;
		case 3: b.Checkbal();
		break;
		default: System.out.println("Invalid Choice:");
		}
	}
}
