package arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Array {

	public static void main(String[] args) {
		
		//int a[]= {10,20,30,40,50};
		
		int a[]=new int[5];
		System.out.println("Enter Array Element: ");
		Scanner sc=new Scanner(System.in);
		
		for(int i=0; i<5; i++) {
			a[i]=sc.nextInt();
		}
		
		Arrays.sort(a);
		System.out.println("Array Elements :");
		
//		System.out.println(a[2]);
//		System.out.println(a[4]);
		
		//For each Loop
		
		for(int b:a) {
			System.out.println(b+" ");
		}

	}

}
