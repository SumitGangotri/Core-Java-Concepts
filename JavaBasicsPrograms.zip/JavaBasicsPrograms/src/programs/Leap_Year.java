package programs;

import java.util.Scanner;

public class Leap_Year {

	public static void main(String[] args) {

		//Divisible by 4 for all the Century Years -- ending with 00.
		
		//Century Year is a Leap Year only when it's perfectly divisible by 400.
		
		//1900 is not a Leap Year.
		
		//2012 Leap Year.
		
		System.out.println("Enter your Year: ");
		
		Scanner sc = new Scanner(System.in);
		
		int year=sc.nextInt();
		
		boolean leap = false;
		
		if(year % 4 == 0) {
			if(year % 100 == 0) {
				if(year % 400 == 0) {
					leap = true;
				}
				else {
					leap = false;
				}
			}
			else {
				leap = true;
			}
		}
		else {
			leap = false;
		}
		
		if(leap) {
			System.out.println(year+ " is a Leap Year");
		}else {
			System.out.println(year+ " Not a Leap Year");
		}
	}

}
