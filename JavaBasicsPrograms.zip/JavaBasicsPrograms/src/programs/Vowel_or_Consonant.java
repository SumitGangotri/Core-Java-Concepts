package programs;

import java.util.Scanner;

public class Vowel_or_Consonant {

	public static void main(String[] args) {

		//Vowel: a e i o u
		
//		char ch='e';
//		
//		if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
//			System.out.println(ch + " is Vowel");
//		}
//		else {
//			System.out.println(ch+ " is Consonant");
//		}
		
		System.out.println("Enter your String: ");
		
		Scanner sc=new Scanner(System.in);
		
		String input=sc.nextLine();
		
		
		
	       //String input = "Capgemini";
	        String vowels = "";

	        // Iterate over each character in the string
	        for (int i = 0; i < input.length(); i++) {
	            char ch = input.charAt(i);
	            
	            // Check if the character is a vowel
	            if (isVowel(ch)) {
	                vowels = vowels+ch;
	            }
	        }

	        System.out.println("Vowels: " + vowels);
	    }

	    // Function to check if a character is a vowel
	    public static boolean isVowel(char ch) {
	        ch = Character.toLowerCase(ch); // Convert character to lowercase for easier comparison

	        return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
	    }
	}

