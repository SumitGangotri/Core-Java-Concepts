package programs;

import java.util.Scanner;

public class Positive_Negative {

	public static void main(String[] args) {
		
		System.out.println("Enter your Number: ");
		
		Scanner sc=new Scanner(System.in);
		
		int num=sc.nextInt();
		
		if(num>0) {
			System.out.println("Number is Positive: "+num);
		}else if(num<0) {
			System.out.println("Number is Negative: "+num);
		}
		else {
			System.out.println("Number is Zero: "+num);
		}
	}

}
