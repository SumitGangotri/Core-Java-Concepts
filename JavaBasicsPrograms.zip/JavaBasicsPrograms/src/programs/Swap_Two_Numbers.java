package programs;

public class Swap_Two_Numbers {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		
		System.out.println("Before Swapping...!");
		System.out.println("Num a is: "+a);
		System.out.println("Num b is: "+b);
//		
//		int c;
//		
//		c=a;
//		a=b;
//		b=c;
//		
//		System.out.println("After Swapping...!");
//		System.out.println("Num a is: "+a);
//		System.out.println("Num b is: "+b);
		
		a=a-b;  //-10
		b=a+b;  //10
		a=b-a;  //20
		
		System.out.println("After Swapping...!");
		System.out.println("Num a is: "+a);
		System.out.println("Num b is: "+b);

	}

}
