package programs;

import java.util.Scanner;

public class Even_and_Odd {

	public static void main(String[] args) {
		
		System.out.println("Enter A Number: ");
		Scanner sc=new Scanner(System.in);
		
		int num=sc.nextInt();
		
		if(num%2==0) {
			System.out.println("Even Number: "+num);
		}else {
			System.out.println("Odd Number: "+num);
		}

	}

}
