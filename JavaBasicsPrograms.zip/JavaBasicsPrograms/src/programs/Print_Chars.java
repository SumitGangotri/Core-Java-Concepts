package programs;

public class Print_Chars {

	public static void main(String[] args) {

		for(char c='A'; c<='Z'; c++) {
			System.out.print(c+" ");
		}
	}

}
