package programs;

public class Largest_Among_Three_Numbers {

	public static void main(String[] args) {
	
		int a=200;
		int b=500;
		int c=300;
		
		if(a>b && a>c) {
			System.out.println("A is the Largest Number: "+a);
		}else if(b>c) {
			System.out.println("B is the Largest Number: "+b);
		}else {
			System.out.println("C is the Largest Number: "+c);
		}
		
		
		if(a>=b) {
			if(a>=c) {
				System.out.println("A is the Largest Number: "+a);
			}else {
				System.out.println("C is Largest Number: "+c);
			}
		}
		else {
			if(b>=c) {
				System.out.println("B is the Largest Number: "+b);
			}else {
				System.out.println("C is the Largest Number: "+c);
			}
		}

	}

}
