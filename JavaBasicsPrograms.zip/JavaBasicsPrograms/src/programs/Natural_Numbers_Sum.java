package programs;

import java.util.Scanner;

public class Natural_Numbers_Sum {

	public static void main(String[] args) {

		System.out.println("Enter a Number: ");
		
		Scanner sc=new Scanner(System.in);
		
		int num=sc.nextInt();
		int sum=0;
		
		for(int i=1; i<=num; i++) {
			sum=sum+i;
		}
		
		System.out.println("Sum is: "+sum);
		
		System.out.println("---------------");
		
		int k=1;
		int sum1=0;
		
		while(k<=num) {
			sum1=sum1+k;
			k++;
		}
		System.out.println("Sum is: "+sum1);
	}

}
