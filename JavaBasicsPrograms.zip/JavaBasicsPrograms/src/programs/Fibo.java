package programs;

import java.util.Arrays;

public class Fibo {

	public static void main(String[] args) {
		// TODO -generated method stub

		int[] arr1 = {11, 34, 66, 75};

	      int[] arr2 = {1, 5, 19, 50};
	      
	      int mergeLength=arr1.length+arr2.length;
	      
	      int[] mergedArray=new int[mergeLength];
	      
	      System.arraycopy(arr1, 0, mergedArray, 0, arr1.length);
	        System.arraycopy(arr2, 0, mergedArray, arr1.length, arr2.length);
	        
	        Arrays.sort(mergedArray);

	        System.out.println("Merged and sorted array: " + Arrays.toString(mergedArray));
		
		int num1=0, num2=1, num3, count=10;
		
		System.out.print("Series :"+ num1 +" "+ num2);
		
		for(int i=0;i<=count;i++) {
			num3=num1+num2;
			System.out.print(" "+num3);
			num1=num2;
			num2=num3;
		}
	      
	}

}
